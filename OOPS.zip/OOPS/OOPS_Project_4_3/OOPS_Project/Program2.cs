﻿
namespace OOPS

{
    class A
    {
        public void c()
        {
            Console.WriteLine("Project2");
        }
    }
}
