﻿

namespace ModelList
{
    //Model
    class EmployeeModel
    {
        //Property
        public int EmpId { get; set; }
        public string EmpFname { get; set; }
        public string EmpLname { get; set; }
        public string EmpContact { get; set; }
        public string EmpEmail { get; set; }
        public char EmpGender { get; set; }

        public EmployeeModel() { }

    }
}
